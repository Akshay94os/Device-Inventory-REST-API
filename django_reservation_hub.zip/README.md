# Lab & Room Reservation Hub

Run:
```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```
