from django.shortcuts import render, redirect
from .models import Resource, Booking
from django.db import IntegrityError

def index(request):
    if Resource.objects.count() == 0:
        Resource.objects.create(name="AI / ML Computer Lab 1", capacity=40, location="Block A, 3rd Floor")
        Resource.objects.create(name="IoT Robotics Workshop", capacity=25, location="Block B, 1st Floor")
        Resource.objects.create(name="Seminar Auditorium", capacity=150, location="Main Building")

    resources = Resource.objects.all()
    bookings = Booking.objects.order_by('-booking_date')[:15]
    error = None

    if request.method == 'POST':
        res_id = request.POST.get('resource')
        name = request.POST.get('booked_by')
        date = request.POST.get('booking_date')
        slot = request.POST.get('slot')
        purpose = request.POST.get('purpose')
        
        try:
            res_obj = Resource.objects.get(id=res_id)
            Booking.objects.create(resource=res_obj, booked_by=name, booking_date=date, slot=slot, purpose=purpose)
            return redirect('reservation_home')
        except IntegrityError:
            error = "Selected Resource is already reserved for this date and time slot!"

    return render(request, 'reservations/index.html', {'resources': resources, 'bookings': bookings, 'error': error})
