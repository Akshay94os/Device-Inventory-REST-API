from django.db import models

class Resource(models.Model):
    name = models.CharField(max_length=100)
    capacity = models.PositiveIntegerField(default=30)
    location = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.name} ({self.location})"

class Booking(models.Model):
    resource = models.ForeignKey(Resource, on_delete=models.CASCADE, related_name='bookings')
    booked_by = models.CharField(max_length=100)
    booking_date = models.DateField()
    slot = models.CharField(max_length=20, choices=[('MORNING','09:00 - 12:00'), ('AFTERNOON','13:00 - 16:00'), ('EVENING','17:00 - 20:00')])
    purpose = models.CharField(max_length=200)

    class Meta:
        unique_together = ('resource', 'booking_date', 'slot')

    def __str__(self):
        return f"{self.resource.name} - {self.booking_date} ({self.slot})"
